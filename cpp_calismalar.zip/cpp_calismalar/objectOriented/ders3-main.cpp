#include "ders3.h"


int main(){

    Employee employee;

    employee.id = 12;

    employee.name = "Furkan Cemal";

    employee.salary = 3000;

    employee.showInfos();


    return 0;
}