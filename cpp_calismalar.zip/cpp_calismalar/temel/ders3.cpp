#include <iostream>

using namespace std;

int main(){
/*
    Matematiksel operatörler

    +,-,*,/

    Arttırma Operatörü
    Azaltma Operatörü

*/

  /*  int sayi1 = 10;
    int sayi2 = 4;

    cout << "Sayi1 + Sayi2 = " << sayi1 + sayi2 << endl;
    cout << "Sayi1 - Sayi2 = " << sayi1 - sayi2 << endl;
    cout << "Sayi1 * Sayi2 = " << sayi1 * sayi2 << endl;
    cout << "Sayi1 / Sayi2 = " << float(sayi1) / sayi2 << endl;
  */

 int a = 5;

 cout << "a'nın değeri: " << a << endl;

    a *= a;

 cout << "a'nın yeni değeri: " << a << endl;












    return 0;
}