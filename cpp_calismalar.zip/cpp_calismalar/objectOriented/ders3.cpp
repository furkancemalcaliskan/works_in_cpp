#include "ders3.h"

void Employee::showInfos(){

    cout << "Id: " << Employee::id << endl;
    cout << "Name: " << Employee::name << endl;
    cout << "Salary: " << Employee::salary << endl;


};