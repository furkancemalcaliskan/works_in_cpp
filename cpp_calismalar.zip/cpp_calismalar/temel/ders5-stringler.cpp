#include <iostream>

using namespace std;

int main() {

string str1 = "Bu bir stringtir.";
string str2 = "Bu da bir stringtir.";

cout << "Str1: " << str1 << endl;
cout << "Str2: " << str2 << endl;

string str3 = str1 + " " + str2;

cout << "Str3: " << str3 << endl;

    return 0;
}