#include <iostream>

using namespace std;

int hesapla(int a, int b, int secim){
float sonuc;
if (secim == 1)
{
    sonuc = a+b;
}else if (secim == 2)
{
    sonuc = a-b;
}else if (secim == 3)
{
    sonuc = a*b;
}else if (secim ==4)
{
    sonuc = (float)a/b;
}

return sonuc;
}

int main(){
int secim,sayi1,sayi2;
    cout << "---Hesap Makinesine Hoş Geldiniz---" << endl << endl;
    cout << "...Yapmak İstediğiniz İşlemi Seçiniz..." << endl;
    cout << "1.Toplama    2.Çıkarma     3.Çarpma     4.Bölme" << endl;
    cin >> secim;
    if(secim!=1||secim!=2||secim!=3||secim!=4){
        cout << "Geçersiz İşlem!!";
    }else{
    cout << "Sayıları Giriniz...";
    cin >> sayi1 >> sayi2;
    cout << "Sonuç: " << hesapla(sayi1,sayi2,secim) << endl;
    }
return 0;
}