#include <iostream>

using namespace std;

int faktoriyelBul(int x){
    int toplam = 1;
    if (x != 0 || x != 1)
    {
        for (int i = 1; i <= x; i++)
        {
            toplam *= i;
        }
        
    }
    else
    {
        toplam = 1;
    }
    

    return toplam;
}

int main(){

int sayi;

cout << "Faktöriyelini bulmak istediğiniz sayıyı giriniz... " << endl;
cin >> sayi;
cout << sayi << "! = " << faktoriyelBul(sayi) << endl;

return 0;
}