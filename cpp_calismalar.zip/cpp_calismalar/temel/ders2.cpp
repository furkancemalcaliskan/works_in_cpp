#include <iostream>

using namespace std;


int main(){

//Değişken tipleri ve Değişkenler

/* int = tam sayi
   float = ondalikli sayi
   double = buyuk ondalikli sayi
   char = karakter
   bool = true(1) - false(0)
*/

int a = 32;

float b = 3.52;

double c = 4.546;

char d = 'A'; //sayı girersek ASCI karşılığı tanımlanır.

bool e = false;

cout << "a değişkeninin değeri: " << a << endl;
cout << "b değişkeninin değeri: " << b << endl;
cout << "c değişkeninin değeri: " << c << endl;
cout << "d değişkeninin değeri: " << d << endl;
cout << "e değişkeninin değeri: " << e << endl;


/*int a, b, c, toplam = 0;

a = 4;
b = 3;
c = 5;

toplam = a + b + c ;

cout << "Toplam: " << toplam << endl;
*/

    return 0;
}