#include <iostream>

using namespace std;

int faktoriyel(int x){
    if (x > 1)
    {
     return x*faktoriyel(x-1);
    }
}

int main(){
    int x;
    cout << "Faktöriyelini bulmak istediğiniz sayıyı giriniz." << endl;
    cin >> x;
    cout << "Sonuç: " << faktoriyel(x) << endl;
    return 0;
}