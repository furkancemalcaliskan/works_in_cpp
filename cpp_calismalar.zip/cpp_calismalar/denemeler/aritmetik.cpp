#include <iostream>
using namespace std;

double aritmetikOrtalama(int toplam, int tane){

float ortalama = (float)toplam / (float)tane;

return ortalama;
}

int main(){
int tane,toplam=0;

    cout << "Kaç tane sayı gireceksiniz?" << endl;
    cin >> tane;

int arr[tane];

    cout << "Ortalamasını almak istediğiniz sayıları girin" << endl;
    for (int i = 0; i < tane; i++)
    {
        cin >> arr[i];
    }
    for (int i = 0; i < tane; i++)
    {
        toplam += arr[i];
    }
    
    
    cout << "Girdiğiniz sayıların ortalaması = " << aritmetikOrtalama(toplam,tane) << endl;

    return 0;
}