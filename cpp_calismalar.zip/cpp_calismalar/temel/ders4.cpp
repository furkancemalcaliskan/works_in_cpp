#include <iostream>

using namespace std;

int main(){

   /* int x;

    cout << "Bir sayi giriniz...";

    cin >> x;

    cout << "Girdiginiz sayi: " << x << endl;

    */
int x,y,z;

   cout << "Üç tane sayi giriniz...";
    cin >> x >> y >> z;

    cout << "Sayıların toplamı: " << x+y+z << endl;






    return 0;
}