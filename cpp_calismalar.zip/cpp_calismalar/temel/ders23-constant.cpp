#include <iostream>

using namespace std;

int main(){

    const int i = 32; //const ifadeler sonradan değiştirilemez.

    cout << i << endl;


    return 0;
}