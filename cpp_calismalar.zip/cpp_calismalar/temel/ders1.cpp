#include <iostream>

using namespace std;

int main(){


    cout << "Merhaba Dünya!" << endl; //endline c'deki \n
    cout << "Merhaba Dünya!2";



    return 0;
}